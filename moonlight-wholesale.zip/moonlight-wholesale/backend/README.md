# Backend (Node + Express + PostgreSQL)

## Setup
```
cp .env.example .env
# edit .env with your DB and Daraja credentials
npm install
npm run dev
```
