# Flutter Client

## Run
```
flutter pub get
flutter run
```
Default API base is `http://10.0.2.2:5000` suitable for Android emulator talking to localhost. Change in `lib/services/api.dart` if needed.
